package com.google.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.domain.Criteria;
import com.google.domain.ReplyPageDTO;
import com.google.domain.ReplyVO;
import com.google.mapper.BoardMapper;
import com.google.mapper.ReplyMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class ReplyServiceImpl implements ReplyService{
	
	@Setter(onMethod_ = {@Autowired})
	private ReplyMapper mapper;
	
	
	@Setter(onMethod_ = {@Autowired})
	private BoardMapper boardMapper;
	
	//댓글추가하므로 replyCnt 가 +1
	//보드 replyCnt 업데이트 된 후에 댓글 insert가 되어야함. 그래서 BoardMapper를 가져와야한다.
	@Transactional
	@Override
	public int insert(ReplyVO vo) {
		boardMapper.updateReplyCnt(vo.getBno(), 1);
		return mapper.insert(vo);
				
	}

	@Override
	public ReplyVO read(long rno) {
		return mapper.read(rno);
	}

	//댓글을 삭제하므로 보드의 replyCnt가 -1이 됨
	@Transactional
	@Override
	public int delete(long rno) {
		ReplyVO vo = mapper.read(rno);
		boardMapper.updateReplyCnt(vo.getBno(), -1);
		return mapper.delete(rno);
	}

	@Override
	public int update(ReplyVO vo) {
		return mapper.update(vo);
	}

	@Override
	public ReplyPageDTO getListWithPaging(Criteria cri, long bno) {
		return new ReplyPageDTO(
				mapper.getCountByBno(bno)
				,mapper.getListWithPaging(cri, bno));
	}
	
	

}
