package com.google.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.google.domain.BoardVO;
import com.google.domain.NewsCriteria;
import com.google.domain.NewsVO;
import com.google.mapper.BoardMapper;
import com.google.mapper.NewsMapper;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class NewsServiceImpl implements NewsService{

	
	private NewsMapper mapper;
	
	@Override
	public List<NewsVO> getList(NewsCriteria ncri) {
		// TODO Auto-generated method stub
		return mapper.getListWithPaging(ncri);
	}

	@Override
	public void register(NewsVO vo) {
		mapper.insert(vo);
		
	}

	@Override
	public NewsVO get(long bno) {
		mapper.updateHit(bno);  //조회수증가
		return mapper.read(bno);
	}

	@Override
	public void remove(long bno) {
		mapper.delete(bno);
		
	}

	@Override
	public void modify(NewsVO vo) {
		mapper.update(vo);
		
	}

	@Override
	public int getListTotal() {
		// TODO Auto-generated method stub
		return mapper.getListTotal();
	}

}
