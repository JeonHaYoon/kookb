package com.google.service;

import java.util.List;

import com.google.domain.Criteria;
import com.google.domain.ReportVO;

public interface ReportService {
	
	public List<ReportVO> getList(Criteria cri);
	
	public int getListTotal(Criteria cri);
	
	public void register(ReportVO vo);   //insert
	
	public ReportVO get(long bno); //read
	
	public void remove(long bno); //delete
	
	public void modify(ReportVO vo); //update

	
	

}
