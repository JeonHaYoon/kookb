package com.google.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.domain.NewsCriteria;
import com.google.domain.NewsPageDTO;
import com.google.domain.NewsVO;
import com.google.service.NewsService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@AllArgsConstructor
@RequestMapping("/news/*")
public class NewsController {

	
	private NewsService service;
	
	
	/**
	 * 목록을 나타내주는 메서드
	 */
	@GetMapping("/list")
	public void list(Model model, NewsCriteria ncri) {
		model.addAttribute("list", service.getList(ncri));
		int total=service.getListTotal();
		model.addAttribute("pageMaker", new NewsPageDTO(total, ncri));
	}
	
	@GetMapping("/register")
	public void register() {
		
	}
	
	@PostMapping("/register")
	public String register(NewsVO news, RedirectAttributes rttr) {
		
		service.register(news);
		
		// news/list로 이동하면서 result값(등록한 글번호)을 전달함
		rttr.addFlashAttribute("result", news.getBno());
		return "redirect:/news/list";
	}
	
	
	//void면 열리는 파일은 news안의 파일 
	//get으로 요청하면 
	@GetMapping({"/get", "/modify" })
	public void get(@RequestParam("bno") long bno, Model model) {
		
		model.addAttribute("news", service.get(bno));
		
	}
	
	/*/get과 /modify가 중복이라 위와 같이 하나로 묶어서 표현할 수 있다.
	 * @GetMapping("/modify") public void modify(@RequestParam("bno") long bno,
	 * Model model) { model.addAttribute("news", service.get(bno)); }
	 */
	
	@PostMapping("/remove")
	public String remove(@RequestParam("bno") long bno, Model model) {
		
		service.remove(bno);
		return "redirect:/news/list";
	}
	
	
	
	
	@PostMapping("/modify")
	public String modify(NewsVO news, RedirectAttributes rttr) {
		
		service.modify(news);
		
		// news/list로 이동하면서 result값(등록한 글번호)을 전달함
		rttr.addFlashAttribute("result", news.getBno());
		return "redirect:/news/list";
	}
}
