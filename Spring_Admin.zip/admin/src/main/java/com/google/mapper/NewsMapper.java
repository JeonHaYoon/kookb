package com.google.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.google.domain.NewsCriteria;
import com.google.domain.NewsVO;

public interface NewsMapper {
	
	//@Select("SELECT * FROM tbl_board ORDER BY bno DESC")
	public List<NewsVO> getList();
	
	public void insert(NewsVO vo);
	
	public Long insertLastId(NewsVO vo);
	
	public NewsVO read(long bno);
	
	public void delete(long bno);
	
	public void update(NewsVO vo);
	
	public void updateHit(long bno);
	
	public List<NewsVO> getListWithPaging(NewsCriteria ncri);
	
	public int getListTotal();
}

