package com.google.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.google.domain.BoardVO;
import com.google.domain.Criteria;

public interface BoardMapper {
	
	//@Select("SELECT * FROM tbl_board ORDER BY bno DESC")
	public List<BoardVO> getList();
		
	//페이징
	public List<BoardVO> getListWithPaging(Criteria cri);
	
	public int getListTotal(Criteria cri);
	
	public void insert(BoardVO vo);
	
	public Long insertLastId(BoardVO vo);
	
	public BoardVO read(long bno);
	
	public void updateHit(long bno);
	
	public int delete(long bno);
	
	public void update(BoardVO vo);
	
	
	//@Param값에 넣어주면 BoardMapper.xml에서 해당 값을 사용할 수 있다.
	public void updateReplyCnt(@Param("bno") long bno, @Param("amount") int amount);
	
	
	
}
