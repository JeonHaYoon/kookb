package com.google.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.service.BoardService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml",
						"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@Log4j
//controller를 위한 test
@WebAppConfiguration
public class BoardControllerTest {
	
	@Setter(onMethod_ = {@Autowired})
	private WebApplicationContext ctx;
	
	//목각으로 만든 휴대폰과 같은 역학, 실제는 아니고 가상의 모형이라고 생각하면 된다.
	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
		
	}
	
	
	//이제 테스트시작
	
	//전체목록
	//@Test
	public void testList() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/board/list"))
				.andReturn()
				.getModelAndView()
				.getModelMap()
				);
	}
	
	
	//글등록
	//@Test
	public void testRegister() throws Exception{
		log.info(mockMvc.perform(MockMvcRequestBuilders.post("/board/register")
				.param("title", "테스트제목")
				.param("content", "테스트내용")
				.param("writer", "user00"))
				.andReturn()
				.getModelAndView()
				.getViewName());
	}
	
	//글조회
	//@Test
	public void testGet() throws Exception{
		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/board/read")
				.param("bno", "1"))
				.andReturn()
				.getModelAndView()
				.getModelMap()
				);
	}
	
	//글삭제
	//@Test
	public void testRemove() throws Exception{
		log.info(mockMvc.perform(MockMvcRequestBuilders.post("/board/remove")
				.param("bno", "1"))
				.andReturn()
				.getModelAndView()
				.getViewName());
	}
	
	//수정, select 빼고 다.getModelMap()  .getViewName()으로 변경해줘야한다
	//@Test
	public void testModify() throws Exception{
		log.info(mockMvc.perform(MockMvcRequestBuilders.post("/board/modify")
				.param("bno", "2")
				.param("title", "테스트수정제목")
				.param("content", "테스트수정내용")
				.param("writer", "user00"))
				.andReturn()
				.getModelAndView()
				.getViewName());
		}
}
