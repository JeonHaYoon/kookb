package com.google.mapper;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.domain.BoardVO;
import com.google.domain.Criteria;
import com.google.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTest {

	@Setter(onMethod_ = {@Autowired})
	private ReplyMapper mapper;
	
	
	//@Test
	public void testGet() {
		log.info("ReplyMapper.....");
	}
	
	//@Test
	public void testInsert() {
		ReplyVO vo = new ReplyVO();
		vo.setBno(3L);
		vo.setReply("댓글내용");
		vo.setReplyer("작성자");
		mapper.insert(vo);
	}
	
	//@Test
	public void testRead() {
		mapper.read(1);
	}
	
	//@Test
	public void testDelete() {
		mapper.delete(1);
	}
	
	//@Test
	public void testUpdate() {
		ReplyVO vo = new ReplyVO();
		vo.setRno(5L);
		vo.setReply("수정된댓글내용");
		mapper.update(vo);
	}
	
	//@Test
	public void testList() {
		Criteria cri = new Criteria(1, 10);
		List<ReplyVO> replies = mapper.getListWithPaging(cri, 262132L);
		replies.forEach(reply-> log.info(reply));
	}
	
	@Test
	public void testGetCount() {
		int res = mapper.getCountByBno(262132L);
		log.info(""+res);
	}
	
	
}
