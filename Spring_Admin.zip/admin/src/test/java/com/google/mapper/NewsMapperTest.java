package com.google.mapper;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.domain.BoardVO;
import com.google.domain.Criteria;
import com.google.domain.NewsCriteria;
import com.google.domain.NewsVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class NewsMapperTest {

	@Setter(onMethod_ = {@Autowired})
	private NewsMapper mapper;
	
	//@Test
	public void testGetList() {
		mapper.getList().forEach(news->log.info(news));
	}
	
	
	//@Test
	public void testGetListWithPaging() {
		NewsCriteria ncri = new NewsCriteria(1,20);
		mapper.getListWithPaging(ncri).forEach(news->log.info(news));
	}
	

	//@Test
	public void testGetListTotal() {
		int total = mapper.getListTotal();
		log.info("[DEG]"+total);
	}
	
	
	
	//@Test
	public void testInsert() {
		NewsVO vo = new NewsVO();
		vo.setTitle("새글제목");
		vo.setContent("새글내용");
		vo.setWriter("user00");
		mapper.insert(vo);
	}
	
	//@Test
	public void testInsertLastId() {
		NewsVO vo = new NewsVO();
		vo.setTitle("새글제목");
		vo.setContent("새글내용");
		vo.setWriter("user00");
		mapper.insertLastId(vo);
		log.info(vo);
	}
	
	//@Test
	public void testRead() {
		mapper.read(54);
	}
	
	//@Test
	public void testDelete() {
		mapper.delete(55);
	}
	
	//@Test
	public void testUpdate() {
		NewsVO vo = new NewsVO();
		vo.setBno(54L);
		vo.setTitle("제목54");
		vo.setContent("내용");
		mapper.update(vo);
	}
}
