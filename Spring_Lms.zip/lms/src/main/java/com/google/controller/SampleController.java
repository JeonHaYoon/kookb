/**
 * parameter 값 받는것
 */

package com.google.controller;

import java.util.ArrayList;
import java.util.Arrays;


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.domain.SampleDTO;
import com.google.domain.SampleDTOList;
import com.google.domain.TodoDTO;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sample/*")
@Log4j
public class SampleController {

	@RequestMapping("")
	public void basic() {
		log.info("basic.......");
	}
	
	
	
	/**
	 * localhost/sample/ex01?name=이름&age=10
	 * 입력하면 값을 받아와서 콘솔창에 name과 age를 나타내준다.
	 * name대신 fname으로 입력하면 fname과 같은 변수가 없어서 name은 null값이 나오게 된다
	 *request.getParameter()
	 * @param dto
	 * @return
	 */
	@GetMapping("/ex01")
	public String ex01(SampleDTO dto) {
		log.info(dto);
		return "ex01";
		
	}
	
	
	/**
	 * fname을 받아와서 name에 값을 넣고, fage를 받아와서 age에 넣는다
	 * @param name
	 * @param age
	 * @return
	 */
	@GetMapping("/ex02")
	public String ex02(@RequestParam("fname") String name,
						@RequestParam("fage") int age) {
		log.info("name: "+name);
		log.info("age: "+age);
		return "ex02";
	}
	
	/**
	 * LIST
	 * ?hobby=야구&hobby=축구&hobby=골프
	 * 같은 이름 (hobby)으로 여러 값을 받을 경우 List배열로 출력한다.
	 * request.getParameterValues()로 값을 받는 것을 이렇게 표현하면 된다.
	 */
	@GetMapping("/ex03")
	public String ex03(@RequestParam("hobby") ArrayList<String> hobbys) {
		log.info("hobbys:" + hobbys);
		return "ex03";
	}
	
	/**
	 * Array.toString
	 * ?hobby=야구&hobby=축구&hobby=골프
	 * 같은 이름 (hobby)으로 여러 값을 받을 경우 String 배열로 출력한다.
	 * request.getParameterValues()로 값을 받는 것을 이렇게 표현하면 된다.
	 * String으로 가져와서 Arrays.toString()으로 출력
	 */
	@GetMapping("/ex04")
	public String ex04(@RequestParam("hobby") String[] hobbys) {
		log.info("hobbys:" + Arrays.toString(hobbys));
		return "ex04";
	}
	
	/**
	 * ?list[0].name=AAA&list[1].name=BBB
	 * 위와 같이 입력하면 []가 유효하지 않는 문자라고 한다.
	 *?list%5b0%5d.name=AAA&list%5b1%5d.name=BBB
	 *위와 같이 [ 를 %5b ]를 %5d 로 변경해서 넣어준다.
	 * @param list
	 * @return
	 */
	@GetMapping("ex05")
	public String ex05(SampleDTOList list) {
		log.info("list" + list);
		return "ex05";
	}
	
	/**
	 * URL에 날짜(2022-11-11)를 전달할 경우 String 에서 java.util.Date로 변환
	 * 
	 */
	/*
	 * @InitBinder public void initBinder(WebDataBinder binder) { SimpleDateFormat
	 * format = new SimpleDateFormat("yyyy-MM-dd");
	 * binder.registerCustomEditor(java.util.Date.class, new
	 * CustomDateEditor(format, false)); }
	 */
	
	/**
	 * ?title=aaaa&dueDate=2022-11-11 는 위의 주석처리 된부분으로 
	 * ?title=aaaa&dueDate=2022/11/11 는 TodoDTO.java의 패턴임
	 */
	@GetMapping("ex06")
	public String ex06(TodoDTO todo) {
		log.info("todo: " + todo);
		return "ex06";
	}
	
	
	/**
	 * @ModelAttribute 어노테이션
	 * ?name=홍길동&age=10&page=20
	 */
	@GetMapping("/ex07")
	public String ex07(SampleDTO dto, @ModelAttribute("page") int page, Model model) {
		log.info("dto:" + dto);
		log.info("page:" + page);
		
		//request.setAtribute("dto",dto); 와 아래 모델 같은겉임
		model.addAttribute("dto", dto);
		
		return "/sample/ex07";
	}
	
	/**
	 * response.sendRedirect();
	 * redirect:/
	 * @return
	 */
	@GetMapping("/ex08")
	public String ex08() {
		return "redirect:/sample/ex07";
		
	}
	
	/**
	 * return void;
	 * 메서드명은 상관없이 mapping된 주소로 결과도출
	 * 메서드이름은 중복만 안되면 된다.
	 */
	@GetMapping("/ex09")
	public void ex0000() {
		log.info("ex09..........");
	}
	
	/**ㄹ
	 * return String;
	 * @return
	 */
	@GetMapping("/ex10")
	public String ex10() {
		return "/sample/ex10";
	}
	
	/**
	 * 
	 */
	@GetMapping("/ex11")
	public @ResponseBody SampleDTO ex11() {
		SampleDTO dto = new SampleDTO();
		dto.setName("홍길동");
		dto.setAge(10);
		return dto;
	}
	
	/**
	 * HTTP의 Header를 다루는 방법
	 * @return
	 */
	@GetMapping("/ex12")
	public ResponseEntity<String> ex12(){
		String msg = "{\"name\":\"홍길동\",\"age\":10}";
		HttpHeaders	 header = new HttpHeaders();
		
		header.add("content-type", "application/json;charset=utf-8");
		
		return new ResponseEntity<String>(msg, header, HttpStatus.OK);
	}
	
	
	/**
	 * 파일업로드 관련 
	 */
	
	@GetMapping("exUpload")
	public void exUpload() {
		log.info("/exUpload...");
	}
	
	@PostMapping("/exUploadPost")
	public void exUploadPost(ArrayList<MultipartFile> files) {
		files.forEach(file->{
			log.info("name: " + file.getOriginalFilename());
			log.info("size:" + file.getSize());
		});
	}
	
	
}
