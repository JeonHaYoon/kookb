package com.google.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/posco/*")
public class PoscoController {
	
	@RequestMapping("/")
	public String posco1() {
		return "/posco/main";
	}
	
	@RequestMapping("/Contact")
	public String posco2() {
		return "/posco/contact";
	}
		
}
