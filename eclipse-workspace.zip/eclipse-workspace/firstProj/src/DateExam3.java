import java.util.Date;

/**
 * java.util.Date
 * @author BigData00
 *
 */
public class DateExam3 {

	public static void main(String[] args) {
		Date now = new Date(System.currentTimeMillis());
		System.out.println(now.getYear()+1900);
		System.out.println(now.getMonth()+1);
		System.out.println(now.getDate());
	}

}
