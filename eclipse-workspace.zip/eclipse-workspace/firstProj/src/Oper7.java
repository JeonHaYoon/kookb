import java.util.Scanner;

/**
 * 엘리베이터 이동
 * @author BigData06
 *
 */
public class Oper7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int currfloor = 1;
		int currelev = 1;
		Scanner scan = new Scanner(System.in);
		while(true) {
			System.out.println("이동할 층을 입력하세요.");
			int floor = scan.nextInt();
			if(floor > 0 && floor < 5 && floor != currelev) {
				System.out.println(floor + "층으로 이동.");
				currelev = floor;
			}
			
			
			
			
		}
	
		
	}

}
