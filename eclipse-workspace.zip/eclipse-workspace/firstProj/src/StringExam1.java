
public class StringExam1 {

	public static void main(String[] args) {
		String s1 = "Hello";
		String s2 = "Hello";		
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));
		
		String s3 = new String("hello");//HELLO
		String s4 = new String("Hello");//HELLO
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
		String s5 = s4;
		System.out.println(s5 == s4);
		System.out.println(s3.equals(s4));
		System.out.println(s3.equalsIgnoreCase(s4));
		
		String s6 = null;
		String s7 = "Hello";
		System.out.println(s7.equals(s6));
	}

}
