
public class MathExam1 {

	public static void main(String[] args) {
		round(Math.PI, 2);
		round(Math.PI, 3);
		round(Math.PI, 4);
	}
	/*
	 * hint : pow()함수사용
	 */
	public static void round(double d, int i) {
		//System.out.println(Math.pow(10, 2));//100.0
		double m = Math.pow(10, i);
		System.out.println(Math.round(d*m)/m);//3.142
	}

}
