
public class CastingExam2 {
	public static void main(String[] args) {
		byte b = (byte)128;
		
		System.out.println(b);
		
		char c = 65;
		System.out.println((int)c);
		
		int i = 65;
		System.out.println((char)i);
	}

}
