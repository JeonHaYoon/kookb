
public class Obj4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//절차적프로그래밍
		//사각형 : Square 삼각형: triangle
		String figure = "star"; //도형
		
		rotation(figure); //함수 호출.
		
	}

	private static void rotation(String figure) {
		// TODO Auto-generated method stub
		int x = 0;
		int y = 0;
		
		switch(figure) {
		case "Square" : 
			x = 100;
			y = 100;
			System.out.println(figure + "의 중심점("+x+","+y+")회전합니다.");
			break;
		case "triangle" :
			x = 90;
			y = 100;
			System.out.println(figure + "의 중심점("+x+","+y+")회전합니다.");		
			break;
		case "star":
			x = 50;
			y = 50;
			System.out.println(figure + "의 중심점("+x+","+y+")회전합니다.");	
			break;
		}
		
		
	}

}
