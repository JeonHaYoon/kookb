/**
 * 배열
 * @author BigData06
 *
 */
public class ArrayExam2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("이름\t국어\t영어\t코딩");
		int studentUnit = 10;
		String [] names = new String[studentUnit];
		int [] kors = new int[studentUnit];
		int [] engs = new int[studentUnit];
		int [] codes = new int [studentUnit];
		
		names[0] = "홍길동";
		kors[0] = 100;
		engs[0] = 90;
		codes[0] = 80;
		
		names[1] = "이순신";
		kors[1] = 10;
		engs[1] = 70;
		codes[1] = 100;
//		String name1 = "홍길순";
//		int kor1 = 10;
//		int eng1 = 80;
//		int code1 = 90;
		
		for(int i = 0; i < names.length; i++) {
			if(names[i] == null) {
				break;
			}
			System.out.printf("%s\t%d\t%d\t%d\n", names[i], kors[i], engs[i], codes[i]);
		}
		
		
		
		
		
	}

}
