
public class Lotto45 {

	public static void main(String[] args) {
		for(int j = 0; j < 6; j++) {
			String row = "";
			for(int i = 0; i < 6; i++) {
				int num = (int)(Math.random()*45+1);//0.0<= num < 45.0
				row += num + ",";
			}
			//시작
			row = row.substring(0, row.length()-1);
			//끝
			System.out.printf("%s", row);//6,31,20,20,17,19, 
			System.out.println();
		}
	}

}
