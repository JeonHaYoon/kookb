package test;

import java.util.Iterator;
import java.util.List;

import domain.MemberDTO;
import domain.MemberVO;
import service.MemberServiceImpl;

public class MemberTests {
	
	public static void main(String[] args) {
		//create();회원등록
		//read();//전체회원목록
		//update();//회원정보수정
		//delete();
		read();
	}

	private static void delete() {
//big003
		MemberServiceImpl service = new MemberServiceImpl();
		service.delete("big003");
	}

	private static void update() {
		MemberDTO dto = new MemberDTO("big003","bigdata", "비그침", 
				"a@a", "12345", "도로명", "구주소", "...", "010-1234-1234", "20220902", "F");
		System.out.println(dto);
		MemberServiceImpl service = new MemberServiceImpl();
		service.update(dto);
	}

	private static void read() {
		MemberServiceImpl service = new MemberServiceImpl();
		List<MemberVO> list = service.read();
		
		Iterator<MemberVO> it = list.iterator();
		while(it.hasNext()) {
			MemberVO vo = it.next();
			System.out.println(vo);
		}
		
	}

	private static void create() {
		MemberDTO dto = new MemberDTO("big003","bigdata", "비오는", 
				"a@a", "12345", "도로명", "구주소", "...", "010-1234-1234", "20220902", "F");
		System.out.println(dto);
		MemberServiceImpl service = new MemberServiceImpl();
		service.create(dto);		
	}

}
