
public class ExceptionExam3 {

	public static void main(String[] args) {
		String msg = null;
		
		if(msg != null) System.out.println(msg.length());
		
		try {
			System.out.println(msg.length());
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
