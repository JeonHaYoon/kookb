import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * 비상연락망
 * @author BigData00
 *
 */
public class HashMapExam5 {

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		map.put("010-1111-1111", "홍길동");
		map.put("010-1111-2222", "이순신");
		map.put("010-3333-2222", "강감찬");
		//Key와 Value를 동시에 출력하시오.
		Set<String> set = map.keySet();
		Iterator<String> it = set.iterator();
		String key = null;
		while(it.hasNext()) {
			key = it.next();
			System.out.printf("%s, %s\n", key, map.get(key));
		}
	}

}
