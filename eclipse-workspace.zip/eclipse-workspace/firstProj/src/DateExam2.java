import java.util.Date;

/**
 * java.util.Date
 * @author BigData00
 *
 */
public class DateExam2 {

	public static void main(String[] args) {
		Date now = new Date(2022-1900, 9-1, 7);
		System.out.println(now.getYear()+1900);
		System.out.println(now.getMonth()+1);
		System.out.println(now.getDate());
		System.out.println("86400" + (60*60*12));
	}

}
