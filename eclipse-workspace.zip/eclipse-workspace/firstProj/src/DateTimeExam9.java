import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 시계를 만들어보세요.
 * @author BigData00
 *
 */
public class DateTimeExam9 {

	public static void main(String[] args) {
		
		
		while(true) {
			String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));	
			System.out.println(now);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {}
		}
	}

}
