/**
 * 타이머를 만드세요
 * @author BigData00
 *
 */
public class DateTimeExam8 {

	public static void main(String[] args) {
		for(int i = 60; i >= 0; i--) {
			System.out.println(i + "초");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {}
		}
	}

}
