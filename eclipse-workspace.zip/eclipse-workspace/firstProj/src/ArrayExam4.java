/**
 * 배열
 * @author BigData06
 *
 */
public class ArrayExam4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("이름\t국어\t영어\t코딩");
		//int studentUnit = 10;
		String [] names = {"홍길동", "이순신"};
		int [][] scores = new int [2][3]; //2학생수, 3은 성적
		scores[0][0] = 100; //홍길동의 국어 점수
		scores[0][1] = 90; //홍길동의 영어점수
		scores[0][2] = 80; //홍길동의 코딩점수
		
		scores[1][0] = 10; //이순신의 국어 점수
		scores[1][1] = 50; //이순신의 영어 점수
		scores[1][2] = 100; //이순신의 코딩 점수
		
		//for문을 이용해서 출력.
		for(int i = 0; i < names.length; i++) {
			System.out.printf("%s\t", names[i]);
			for(int j = 0; j < scores[i].length; j++) {
				System.out.printf("%d\t", scores[i][j]);
			}
			System.out.println();
		}
		
//		System.out.printf("%s\t%d\t%d\t%d\n", names[0], scores[0][0], scores[0][1], scores[0][2]);
//		System.out.printf("%s\t%d\t%d\t%d\n", names[1], scores[1][0], scores[1][1], scores[1][2]);
	}
	
			
		
		
		
		
	}


