
public class MethodExam2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		
		 MethodExam2  me = new MethodExam2();
		i = me.plus(i);
		
		System.out.println("i값 : " + i);
		
	}

	private int plus(int i) {
		// TODO Auto-generated method stub
		i++;
		//System.out.println("i값 : " + i);
		return i;
	}
	
	private static void plus2(int i) {
		// TODO Auto-generated method stub
		i++;
		//System.out.println("i값 : " + i);
		return;
	}

}
