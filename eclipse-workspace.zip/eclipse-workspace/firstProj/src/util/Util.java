package util;

public class Util {
	/**
	 * 학점을 출력한다.
	 * @param myjumsu
	 */
	public void mySungjuk(int myjumsu) {
		//int myjumsu = 50;
		
		if(myjumsu >= 90) System.out.println("A");
		else if(myjumsu >= 80) System.out.println("B");
		else if(myjumsu >= 70) System.out.println("C");
		else if(myjumsu >= 60) System.out.println("D");
		else System.out.println("F");
		
	}
	
	/**
	 * 2~9단 구구단을 출력합니다.
	 */
	
	public void getGugudan() {
		//구구단 이중 포문 2~9단.
				for (int dan = 2; dan < 10; dan++) {
					//System.out.println(); //print("\n")과 동일.
					for (int i = 1; i < 10; i++) {
						System.out.print(dan + " * " + i + " = " + (dan * i));
						System.out.print("\t");
					}
					System.out.print("\n");
				}
	
	
	
	}
	/**
	 * 값을 정렬합니다.
	 */
	public void Sort() {

		// 5칸의 배열을 생성하고 3, 4, 2, 1, 5 값을 입력후
		// 1,2,3,4,5로 출력하게.
		//for문 2개 + if문 + 치환
		int[] arr = { 3, 4, 2, 1, 5 };
		int tmp = 0;

		for (int i = 0; i <	arr.length; i++) {

			for (int j = 0; j < arr.length - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					tmp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = tmp;
				}
			}
		}
		/*for(int i = 0; i < arr.length; i++){
		 * for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;
				}
			}
		 * 
		 * 
		 * 
		 * 
		 * */
		// 출력문 수정 x.
		for (int data : arr) {

			System.out.print(data + " ");

		}
	}
	
	/**
	 * 값을 정렬합니다.2
	 */
	public void Sort(int [] arr) {

		// 5칸의 배열을 생성하고 3, 4, 2, 1, 5 값을 입력후
		// 1,2,3,4,5로 출력하게.
		//for문 2개 + if문 + 치환
		//int[] arr = { 3, 4, 2, 1, 5 };
		int tmp = 0;

		for (int i = 0; i <	arr.length; i++) {

			for (int j = 0; j < arr.length - 1; j++) {
				if (arr[j] > arr[j + 1]) {
					tmp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = tmp;
				}
			}
		}
		/*for(int i = 0; i < arr.length; i++){
		 * for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;
				}
			}
		 * 
		 * 
		 * 
		 * 
		 * */
		// 출력문 수정 x.
		for (int data : arr) {

			System.out.print(data + " ");

		}
	}
	
}
