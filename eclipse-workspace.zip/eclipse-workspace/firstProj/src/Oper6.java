/**
 * 엘리베이터
 * 550KG, 8인제한
 * @author BigData06
 *
 */
public class Oper6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int weight = 550;
		int personnel = 8;
		
		//조건 최대 550kg이상 또는 8인 이상이면 "만원입니다. 내리세요"라고 출력한다.
		
		if(weight >= 550 || personnel >= 8 ) {
			System.out.println("만원입니다. 내리세요");
		}
	}

}
