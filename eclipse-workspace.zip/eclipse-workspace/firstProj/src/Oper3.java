import java.util.Scanner;

/**
 * 관계 연산자
 * @author BigData06
 *
 */
public class Oper3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int year = sc.nextInt();
		
		
//		if (i >= 80) {
//			System.out.println("A");
//		}
//		else if(i >= 60 && i < 80 ) {
//			System.out.println("B");
//		}
//		else {
//			System.out.println("C");
//		}
		
		
		
		
		
//		System.out.println(20 > 20); //false
//		System.out.println(20 >= 20); //true
//		System.out.println(20 < 20); //false
//		System.out.println(20 <= 20);//true
//		System.out.println(20 == 20);//true
//		System.out.println(20 != 20);//false
		
	}
}
