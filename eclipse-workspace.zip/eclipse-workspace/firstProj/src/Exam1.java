/*
 * 두변수를 선언 및 초기화하고 결과값을 다르게 나오게 하세요.
 * 입력값 1, 2 ==> 출력값 2, 1
 * 
 * 
 * 
 * */


public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10, b = 2;
		
		int c = 0;
		c = a;
		a = b;
		b = c;
		/*
		 * 1. a, b, c 3개의 컵을 준비한다
		 * 2. a컵에 담긴 내용물을 빈컵인 c번째컵에 담는다.
		 * 3. a컵은 비어있으니 b컵의 내용물을 a컵에 담는다.
		 * 4. c컵의 내용물을 b컵에 담는다.
		 * */
		
		
		
		
		System.out.printf("a=%d, b=%d", a, b);
	}

}
