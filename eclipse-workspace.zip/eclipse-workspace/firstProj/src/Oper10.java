/**
 * 성적처리프로그램 if문 사용
 * @author BigData06
 *
 */
public class Oper10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int myjumsu = 90;
		
		myjumsu = myjumsu / 10; 
		
		
		switch (myjumsu) {
		case 10: System.out.println("A"); break;
		case 9: System.out.println("A"); break;
		case 8: System.out.println("B"); break;
		case 7: System.out.println("C"); break;
		case 6: System.out.println("D"); break;
		default:
			System.out.println("F");
		}
		
//		if(myjumsu >= 90) System.out.println("A");
//		else if(myjumsu >= 80) System.out.println("B");
//		else if(myjumsu >= 70) System.out.println("C");
//		else if(myjumsu >= 60) System.out.println("D");
//		else System.out.println("F");
		
	}

}
