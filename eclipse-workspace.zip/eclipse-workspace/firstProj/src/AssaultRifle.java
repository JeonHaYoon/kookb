
public class AssaultRifle extends Gun {

	public AssaultRifle(String model) {
		// TODO Auto-generated constructor stub
		super(model);
		this.bulletCount = 40;
	}

	@Override
	public void fire() {
		// TODO Auto-generated method stub
//		super.fire();
		System.out.println("=> => => => =>");
		this.bulletCount -= 5;
	}

}
