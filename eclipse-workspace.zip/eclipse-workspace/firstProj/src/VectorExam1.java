import java.util.Vector;
import java.util.Iterator;
import java.util.List;

public class VectorExam1 {

	public static void main(String[] args) {
		List<String> list = new Vector<>();
		list.add("A");
		list.add("B");

		Iterator<String> it = list.iterator();

		while (it.hasNext()) {
			String str = it.next();
			System.out.println(str);
		}
		System.out.println("=====================");
		
		it = list.iterator();
		while (it.hasNext()) {
			String str = it.next();
			System.out.println(str);
		}
	}

}
