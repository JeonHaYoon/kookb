
public class Obj3 {

	public static void main(String[] args) {
		String figure = "star";
		// TODO Auto-generated method stub
		//객체지향프로그래밍
		switch(figure) {
		case "Square" : 
			Square square = new Square();
			
			square.x = 100;
			square.y = 100;
			square.rotation();
			break;
		case "triangle" : 
			Triangle triangle = new Triangle();
			
			triangle.x = 90;
			triangle.y = 100;
			triangle.rotation();
			break;
		case "star" : 
			Star star = new Star();
			
			star.x = 90;
			star.y = 100;
			star.rotation();
			break;
		}
		
		
		
	}

}
