
public class Loop1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//0 ~ 9까지 반복.
		//for(초기값; 조건식; 증감식) {
		//수행문1;
		//수행문2;
		
//	}
//		int i = 0;
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
//		System.out.println(i++);
		int j = 0;
		
//		//1부터 10까지 반복
//		for(int i = 1; i < 101; i++) {
//			System.out.println(i);
//		}
		while(j < 11) {
			
			System.out.println(j++);
		}
	}

}
