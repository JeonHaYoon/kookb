
public class Obj1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String 문자열
		char [] modelName = {'K', 'B', '계', '산', '기'};
		for (int i = 0; i < modelName.length; i++) {
			System.out.print(modelName[i]);
		}
		System.out.println();
		String color = "흰색"; //차량 색상
		String model = "Benz"; //모델명
		int power = 200; //마력
		System.out.printf("%s, %s, %d\n", model, color, power);
		
		String color2 = "검정색"; //차량 색상
		String model2 = "아반떼"; //모델명
		int power2 = 200; //마력
		System.out.printf("%s, %s, %d", model2, color2, power2);
		
		
		
	}
	class Car{
		
	}
	
	

}
