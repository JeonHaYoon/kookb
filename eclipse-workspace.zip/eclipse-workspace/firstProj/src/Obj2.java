
public class Obj2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//클래스의 객체생성
		Car car1 = new Car(); //car1객체 선언.
		//car1 = new Car(); //인스턴스화 한다.
		
		//객체의 속성에 값 설정
		car1.color = "회색";
		car1.model = "아반떼";
		car1.power = 190;
		
		//객체의 속성값 출력.
		System.out.printf("%s, %s, %d\n",  car1.model, car1.color, car1.power);
		
		Person 사람1 = new Person();
		
		사람1.name = "강성준";
		사람1.sex = "남자";
		사람1.age = 25;
		
		System.out.printf("%s, %s, %d",  사람1.name, 사람1.sex, 사람1.age);
	}

	
	static class Person {
		String name;
		String sex;
		int age;
		
		
	}
}
