
public abstract class Pet {

	abstract void bark();
}

	class Dog extends Pet {
		
		@Override
		void bark() {
			System.out.println("woof woof");
		}
	}

	class Cat extends Pet {

		void bark() {
			System.out.println("woof woof");
		}
	}
