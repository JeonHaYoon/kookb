import java.util.Arrays;

/**
 * 
 * @author BigData06
 *
 */
public class ArrayExam7 {

	public static void main(String[] args) {
		// 5칸의 배열을 생성하고 3, 4, 2, 1, 5 값을 입력후
		// 1,2,3,4,5로 출력하게.
		//for문 2개 + if문 + 치환
		int[] arr = { 3, 4, 2, 1, 5 };
		//int tmp = 0;

		Arrays.sort(arr);
//		for (int i = 0; i <	arr.length; i++) {
//
//			for (int j = 0; j < arr.length - 1; j++) {
//				if (arr[j] > arr[j + 1]) {
//					tmp = arr[j];
//					arr[j] = arr[j + 1];
//					arr[j + 1] = tmp;
//				}
//			}
//		}
		/*for(int i = 0; i < arr.length; i++){
		 * for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;
				}
			}
		 * 
		 * 
		 * 
		 * 
		 * */
		// 출력문 수정 x.
		for (int data : arr) {

			System.out.print(data + " ");

		}
	}
}

