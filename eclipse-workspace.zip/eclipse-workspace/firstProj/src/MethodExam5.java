import util.Util;

public class MethodExam5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Util util = new Util();
		//util.getGugudan(); //구구단
		//util.Sort(); //값이 정해진 배열 정렬.
		int [] arr = {30, 20, 8, 1, 5};
		//util.Sort(arr);
		util.mySungjuk(80);
	}

}
