/**
 * if문을 switch문으로 변경
 * @author BigData06
 *
 */
public class Oper8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		
		switch (i) {
		case 1:
			System.out.println("로그인 호출");
			//break;
		case 2:
			System.out.println("쪽지확인");
			break;
		case 0:
			System.out.println("종료");
			break;
		default:
			System.out.println("잘못입력하셨습니다.");
		}
//		if(i == 1) {
//			System.out.println("로그인 호출");
//		}
//		else if(i == 2) {
//			System.out.println("쪽지확인");
//		}
//		else if(i == 0) {
//			System.out.println("종료");
//		}
//		else {
//			System.out.println("잘못입력하셨습니다.");
//		}
		
	}

}
