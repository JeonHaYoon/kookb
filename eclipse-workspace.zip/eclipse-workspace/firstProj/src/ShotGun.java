
public class ShotGun extends Gun {

	public ShotGun(String model) {
		// TODO Auto-generated constructor stub
		super(model);
		
		
		
		
	}
	@Override
	public void fire() {
		// TODO Auto-generated method stub
		//super.fire();
		System.out.println(" => ");
		this.bulletCount -= 1;
	}
	
	
}
