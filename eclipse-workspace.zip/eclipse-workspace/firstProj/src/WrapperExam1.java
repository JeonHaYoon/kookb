
public class WrapperExam1 {

	public static void main(String[] args) {
		int j = 7;
		
		double d = .123;
		System.out.println(d);
		
		Integer i = Integer.parseInt("7");
		System.out.println(i+1);
		System.out.println(i.MAX_VALUE);
		System.out.println(i.MIN_VALUE);
		System.out.println(i.doubleValue());
		
	}

}
