import java.util.Date;

/**
 * java.util.Date
 * @author BigData00
 *
 */
public class DateExam1 {

	public static void main(String[] args) {
		Date now = new Date();
		System.out.println(now);
		System.out.println(now.getYear()+1900);
		System.out.println(now.getMonth()+1);
		System.out.println(now.getDate());
	}

}
