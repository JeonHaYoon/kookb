/**
 * 두수의 변수를 선언하고 사칙연산을 수행하시오.
 * +, -, *, %
 * 
 * */
public class Oper1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 5;
		int j = 2;
		
		//증감연산자 ++, --
		//전위, 후위연산자
		//j = j + 1;
		//j += 1;
		//j++; 후위연산
		//++j; 전위연산
		//j = j + 1;
		System.out.println("[DEG]J="+(j++));
		
		
		i += 2;
		System.out.println("[DEG]I="+i);
		
		int res = i + j;
		System.out.println("[DEG]res="+res);
		
		res = i - j;
		System.out.println("[DEG]res="+res);
		
		res = i * j;
		System.out.println("[DEG]res="+res);
		
		res = i / j;
		System.out.println("[DEG]res="+res);
		
		res = (i % j);
		System.out.println("[DEG]res="+res);
	}

}
