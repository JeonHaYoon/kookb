
public class MethodExam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		
		i = plus(i);
		
		System.out.println("i값 : " + i);
		
	}

	private static int plus(int i) {
		// TODO Auto-generated method stub
		i++;
		//System.out.println("i값 : " + i);
		return i;
	}
	
	private static void plus2(int i) {
		// TODO Auto-generated method stub
		i++;
		//System.out.println("i값 : " + i);
		return;
	}

}
