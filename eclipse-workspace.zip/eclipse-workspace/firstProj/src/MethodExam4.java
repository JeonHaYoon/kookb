
public class MethodExam4 {

	public MethodExam4() {
		System.out.println("#생성자 : 홍길동");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//타입 변수명 = new타입();
		MethodExam4 me = new MethodExam4();
		
		me.printName();
		me.printName("홍길동");
		/**
		 * 두수를 전달하여 두수의 합을 리턴하는 함수를 정의하시오.
		 * #calc(int num1, int num2): 70 
		 */
		int res = me.calc(30, 40);
		System.out.println("#calc(int num1, int num2): " + res);
	}
	private int calc(int num1, int num2) {
		// TODO Auto-generated method stub
		return num1 + num2;
	}
	private void printName(String name) {
		// TODO Auto-generated method stub
		System.out.println("#printName(String name): " +  name);
	}
	private void printName() {
		// TODO Auto-generated method stub
		System.out.println("#printName(): 홍길동");
	}	

}
