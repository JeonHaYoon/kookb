/**
 * 성적처리프로그램 if문 사용
 * @author BigData06
 *
 */
public class Oper9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int myjumsu = 50;
		
		if(myjumsu >= 90) System.out.println("A");
		else if(myjumsu >= 80) System.out.println("B");
		else if(myjumsu >= 70) System.out.println("C");
		else if(myjumsu >= 60) System.out.println("D");
		else System.out.println("F");
		
	}

}
