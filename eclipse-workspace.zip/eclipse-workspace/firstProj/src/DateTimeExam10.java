/**
 * 421초를 입력하면 "1시 1분 1초" 가 출력되게하세요.
 * @author BigData00
 *
 */
public class DateTimeExam10 {

	public static void main(String[] args) {	
		//끝
		int sec = 11490;
		
		while(true) {
			
			
			int h = 0;
			int m = 0;
			int s = 0;		
			
			//시작
			h = sec/(60*60);	
			m = (sec/60)%60;		
			s = sec%60;	
			
			System.out.println(h+"시 "+(m<10?"0":"")+m+"분 "+String.format("%02d", s)+"초");
			
			sec++;
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {}
		}
	}

}



