
public class ExceptionExam2 {

	public static void main(String[] args) {
		ExceptionExam2 ee2 = new ExceptionExam2();
		try {
			ee2.aaa(0);
		} catch(Exception e) {}
		System.out.println("예외처리가 되었나요???");
	}

	private void aaa(int i) throws ArithmeticException {
		System.out.println(10/i);
	}

}
