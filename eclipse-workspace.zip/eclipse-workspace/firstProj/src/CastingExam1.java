
public class CastingExam1 {

	public static void main(String[] args) {
		int num1 = 1, num2 = 4;
		double res1 = num1/num2;
		System.out.println(res1);
		
		double res2 = (double)num1/(double)num2;
		System.out.println(res2);
		
		double res3 = num1/(num2*1.);
		System.out.println(res3);
	}

}
