import java.util.HashSet;
import java.util.Iterator;

public class Lotto46 {

	public static void main(String[] args) {
		//시작
		//int chk = 0;
		
		for(int i = 0; i < 5; i++) {
			HashSet<Integer> lotto = new HashSet<>();
			while(true) {
				lotto.add((int)(Math.random()*45+1));
				
				if(lotto.size() == 6) {
					break;
				}
			}
			//끝
			Iterator<Integer> it = lotto.iterator();
			while(it.hasNext()) {
				System.out.print(it.next()+", ");
			}
			System.out.println();
		}
		
		
	}

}
