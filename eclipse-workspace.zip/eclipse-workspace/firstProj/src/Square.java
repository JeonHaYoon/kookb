/**
 * 사각형
 * @author BigData06
 *
 */
public class Square extends Figure{

}
