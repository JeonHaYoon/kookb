
public class GunGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//AssaultRifle ar = new AssaultRifle("stg44");
		//ShotGun ar = new ShotGun("M500");
		//Gun ar = new AssaultRifle("stg44");
		Gun ar = new ShotGun("M500");
		ar.fire();
		System.out.println("남은 총알 수 = " + ar.bulletCount);
		
	}

}
