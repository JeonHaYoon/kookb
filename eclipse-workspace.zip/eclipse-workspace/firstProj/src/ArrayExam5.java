/**
 * 배열
 * @author BigData06
 *
 */
public class ArrayExam5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("이름\t국어\t영어\t코딩");
		//int studentUnit = 10;
		String [] names = {"홍길동", "이순신"};
		int [][] scores = {{100, 90, 80}, 
						   {10, 60, 90}}; //2학생수, 3은 성적
		//for문을 이용해서 출력.
		for(int i = 0; i < names.length; i++) {
			System.out.printf("%s\t", names[i]);
			for(int j = 0; j < scores[i].length; j++) {
				System.out.printf("%d\t", scores[i][j]);
			}
			System.out.println();
		}
		
//		System.out.printf("%s\t%d\t%d\t%d\n", names[0], scores[0][0], scores[0][1], scores[0][2]);
//		System.out.printf("%s\t%d\t%d\t%d\n", names[1], scores[1][0], scores[1][1], scores[1][2]);
	}
	
			
		
		
		
		
	}


