/**
 * 성적프로그램
 * @author BigData06
 *
 */
public class Obj6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Record score = new Record("홍길동", 70, 80, 90);
		Record score2 = new Record("이순신", 50, 80, 100);
		
		
		System.out.println(score.toString());
		System.out.println(score2.toString());
		
		//methodExam();
		//methodExam("문자열", 111);
		//methodExam(new Car());
		int i = methodExam2();
		String str = methodExam2("홍길동");
		System.out.println(str);
	}

	private static String methodExam2(String str) {
		// TODO Auto-generated method stub
		return str + "님";
	}

	private static int methodExam2() {
		// TODO Auto-generated method stub
		return 111;
	}

	private static void methodExam(Car car) {
		// TODO Auto-generated method stub
		System.out.println(car.model);
	}

	private static void methodExam(String str, int i) {
		// TODO Auto-generated method stub
		System.out.println("메소드 호출됨." + str + i);
	}

	private static void methodExam(String str) {
		// TODO Auto-generated method stub
		System.out.println("메소드 호출됨." + str);
	}

	private static void methodExam() {
		// TODO Auto-generated method stub
		System.out.println("메소드 호출됨.");
		
	}

}
