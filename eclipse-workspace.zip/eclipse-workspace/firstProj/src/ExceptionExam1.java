import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ExceptionExam1 {

	public static void main(String[] args) {
		File file = new File("test.txt");
		try {
			Scanner scan = new Scanner(file);
			System.out.println("예외상황시 실행");
		} catch (FileNotFoundException e) {
			System.out.println(e.getLocalizedMessage());
		}
	}

}
