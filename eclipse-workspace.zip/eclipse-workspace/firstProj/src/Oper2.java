/**
 * 정수 50을 10진수와 2진수로 출력하세요.
 * @author BigData06
 *
 */
public class Oper2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 50;
		System.out.printf("정수 %d는 2진수 %s 입니다.", i, Integer.toBinaryString(i));
		
	}

}
