/**
 * 사각형
 * @author BigData06
 *
 */
public class Star extends Figure{
//	int x;
//	int y;
//	
//	public void rotation() {
//		System.out.println(this.getClass().getName() + "의 중심점("+x+","+y+")회전합니다.");
//	}
}
