import util.Util;

/**
 * 구구단을 출력하시오.
 * 2단을 출력.
 * @author BigData06
 *
 */
public class Loop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Util util = new Util();
		util.getGugudan();
//		int i = 1;
//		int j = 1;
//		int k = 1;
		
		//구구단 이중 포문 2~9단.
//		for (int dan = 2; dan < 10; dan++) {
//			//System.out.println(); //print("\n")과 동일.
//			for (i = 1; i < 10; i++) {
//				System.out.print(dan + " * " + i + " = " + (dan * i));
//				System.out.print("\t");
//			}
//			System.out.print("\n");
//		}
//		for(int i = 0; i < 11; i++) {
//			System.out.println(i);
//		}
//		
//		int i = 1;
//		int j = 1;
//		
//		while(i < 11) {
//			System.out.println(i);
//			i++;
//		}
//		
//		do {
//			System.out.println(j);
//			j++;
//		} while(j < 11);
//		
//		while(j < 10) {
//			System.out.println(dan + " * " + j + " = " + (dan*j));
//			j++;
//		}
//		
//		do {
//			System.out.println(dan + " * " + k + " = " + (dan*k));
//			k++;
//		} while(k < 10);
		
		
		
	
	}
}
