import java.util.Scanner;

/**
 * 윤년 계산
 * 연수가 4년마다 윤년이다.
 * 100년마다 윤년이 아니다.
 * 그렇지만 400년마다 윤년이다.
 * @author BigData06
 *
 */
public class Oper5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//		Scanner sc = new Scanner(System.in);
//		int year = sc.nextInt();
		int year = 1600;
		if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
			System.out.printf("%d년은 윤년입니다.", year);
		} else {
			System.out.printf("%d년은 평년입니다.", year);
		}
		
	}

}
