import java.sql.Date;

/**
 * java.sql.Date
 * @author BigData00
 *
 */
public class DateExam4 {

	public static void main(String[] args) {
		Date now = new Date(System.currentTimeMillis());
		System.out.println(now);
	}

}
