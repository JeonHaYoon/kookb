
public class Obj5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car car = new Car("모델명", "차량색상", 190);
		System.out.printf("%s, %s, %d", car.model, car.color, car.power);
		
	}

}
