
public class StringExam2 {

	public static void main(String[] args) {
		String s1 = "Hello H  World     ";
		System.out.println("[DEG][" + s1 + "]");
		System.out.println("[DEG][" + s1.trim() + "]");
		System.out.println("[DEG][" + s1.substring(s1.indexOf("H"), 6) + "]");
		System.out.println("[DEG][" + s1.substring(6) + "]");
		System.out.println("[DEG][" + s1.replace("World", "Java") + "]");
		System.out.println("[DEG][" + s1.indexOf("H") + "]");
		System.out.println("[DEG][" + s1.lastIndexOf("H") + "]");
		System.out.println("[DEG][" + s1.charAt(2) + "]");
		System.out.println("[DEG]"+s1.startsWith(" Hel"));
		System.out.println("[DEG]"+s1.length());
		System.out.println("[DEG]"+s1.concat("s"));
		int ii = 99;
		System.out.println("[DEG]" + String.format("%03d",ii));
		
		String cars = "hyundai,mercedaes#bmdaw".toUpperCase();
		String[] carSplit = cars.split("dm");
		
		for (int i = 0; i < carSplit.length; i++) {
			System.out.println(carSplit[i]);	
		}
		
	}

}
