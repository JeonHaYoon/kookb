/**
 * 10 ~ 1 까지 값을 출력하시오. for문 사용.
 * @author BigData06
 *
 */
public class Loop3 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0;
		int j = 0;
		int k = 0;
		int m = 0;
		int n = 0;
		int o = 0;
		int p = 0;
		int q = 0;
		int a = 0;
		int b = 1;
		int c = 0;
		int sum = 0;
		int jjak = 0;
		int hole = 0;
		int sum1 = 0;
		int sum2 = 0;
		int holesu = 0;
		int hap = 0;
		int sum3 = 0;
		
		
		
		
		
		
		//10~1 까지 값을 출력. for문 사용.
		for( i = 10; i > 0; i--) {
			System.out.println(i);
		}
		//1~100까지 합
		for( j = 1; i<101; i++) {
			sum = sum + i;
		}
		System.out.println("1부터 100까지의 합은 = " + sum + "입니다.");
		
		//홀 수의 합
		for( k = 1; k < 11; k++) {
			if(k % 2 != 0) {
				holesu = holesu + k;
			}
		}
		System.out.println("1부터 10까지 홀 수의 합은 = " + holesu + "입니다.");
		
		//1~10까지 짝수의 합 출력.
		for(m = 1; m < 11; m++) {
			if(m % 2 == 0) {
				jjak = jjak + m;
			}
			
		}
		System.out.println("1부터 10까지 짝 수의 합은 = " + jjak + "입니다.");
		//1~10까지 짝수 합, 홀수 합, 전체 합 출력.
		
		for(n = 1; n < 11; n++) {
			if(n % 2 == 0) {   //짝수 합
				sum1 = sum1 + n;
			}
			else if(n % 2 != 0) { //홀수 합
				hole = hole + n;
			}
//			else {
//				hole = hole + n;
//			}
			sum2 = sum2 + n;   // 전체 합.
		}
		System.out.println("짝수의 합 = " + sum1);
		System.out.println("홀수의 합 = " + hole);
		System.out.println("전체의 합 = " + sum2);
		
		//A~Z까지 출력.(형식지정자를 통해 출력)
		
		for(o = 65; o < 91; o++) {
			System.out.printf("%c", o);
		}
		System.out.println();
		
		//A~Z까지 출력 (형변환을 통해 출력)
		for(p = 0; p < 26; p++) {
			System.out.println((char)('A'+ p));
		
		}
		// 피보나치 수열
		System.out.println(a);
		System.out.println(b);
		for(q = 0; q < 10; q++) {
		
			c = a + b;
			a = b;
			b = c;
			
		
			
			System.out.println(c);
			
		}
		//오버플로우, 언더플로우 --> 최대값에서 더하면 최솟값. 
		//최소값에서 빼면 최대값.
		byte by = 127;
		System.out.println(++by);

	}

}
