/**
 * 배열
 * @author BigData06
 *
 */
public class ArrayExam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("이름\t국어\t영어\t코딩");
		String name0 = "홍길동";
		int kor0 = 100;
		int eng0 = 90;
		int code0 = 90;
		
		System.out.printf("%s\t%d\t%d\t%d\n", name0, kor0, eng0, code0);
		System.out.println("이름\t국어\t영어\t코딩");
		String name1 = "홍길순";
		int kor1 = 10;
		int eng1 = 80;
		int code1 = 90;
		
		
		System.out.printf("%s\t%d\t%d\t%d\n", name1, kor1, eng1, code1);
		
		
		
		
	}

}
