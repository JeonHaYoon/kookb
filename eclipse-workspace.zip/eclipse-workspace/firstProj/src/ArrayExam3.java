/**
 * 배열
 * @author BigData06
 *
 */
public class ArrayExam3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("이름\t국어\t영어\t코딩");
		//int studentUnit = 10;
		String [] names = {"홍길동", "이순신"};
		int [] kors = {100, 50};
		int [] engs = {90, 60};
		int [] codes = {80, 100};
		
		for(int i = 0; i < names.length; i++) {
			if(names[i] == null) {
				break;
			}
			System.out.printf("%s\t%d\t%d\t%d\n", names[i], kors[i], engs[i], codes[i]);
		}
		
		
		
		
		
	}

}
