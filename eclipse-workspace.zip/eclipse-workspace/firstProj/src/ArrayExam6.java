
public class ArrayExam6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 피보나치 수열
		//int [] pibo = {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		int [] pibo = new int[11];
		pibo[0] = 0;
		pibo[1] = 1;
		
//		pibo[0] = pibo[1];
//		pibo[1] = pibo[2];
		for(int i = 2; i < 11; i++) {
			pibo[i] = pibo[i - 2] + pibo[i - 1]; 
		}
		
		
//		pibo[2] = pibo[0] + pibo[1];
//		pibo[0] = pibo[1];
//		pibo[1] = pibo[2];
		
		for(int j = 0; j < pibo.length; j++) {
			
//			pibo[q] = pibo[q + 1];
//			pibo[q + 1] = pibo[q + 2];
			
		System.out.println(pibo[j]);
		
		}
	}

}
