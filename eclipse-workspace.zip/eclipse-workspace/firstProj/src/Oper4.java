import java.util.Scanner;

public class Oper4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
//		int year = sc.nextInt();
//		if((year % 4) == 0 && (year % 100) != 0 || ((year % 400) == 0)){
//			System.out.println("윤년입니다.");
//		}
		int i = 3;
		
		if(i % 2 == 1) {
			System.out.println("홀수입니다.");
		}
		if(i % 2 == 0) {
			System.out.println("짝수입니다.");
		}
//		if(i % 2 ==1) {
//			System.out.println("홀수입니다.");
//		}
//		else {
//			System.out.println("짝수입니다.");
//		}
//		
	}

}
