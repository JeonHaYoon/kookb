/**
 * 성적프로그램
 * @author BigData06
 *
 */
public class Record {

	String name;
	int eng;
	int kor;
	int code;
	
	
	
	public Record() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Record(String name, int eng, int kor, int code) {
		super();
		this.name = name;
		this.eng = eng;
		this.kor = kor;
		this.code = code;
	}



	@Override
	public String toString() {
		return "Record [name=" + name + ", eng=" + eng + ", kor=" + kor + ", code=" + code + "]";
	}
	
	
	
}
