
public class Car {
	//속성(멤버변수)
	String color;   //= "흰색"; //차량 색상
	String model;   //= "Benz"; //모델명
	int power;      //= 200; //마력
	
	
	//디폴트 생성자
	public Car() {
		System.out.println("디폴트 생성자는 자동으로 만들어져요.");
	}


	public Car(String model, String color, int power) {
		// TODO Auto-generated constructor stub
		this.model = model;
		this.color = color;
		this.power = power;
	}
	
	
	
	//메소드
}
