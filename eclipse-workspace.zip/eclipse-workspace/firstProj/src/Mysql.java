import java.sql.*;

public class Mysql {

	public static void main(String[] args) {
	      // TODO Auto-generated method stub
	      
	      String jdbc_driver = "com.mysql.cj.jdbc.Driver";
	      String jdbc_url = "jdbc:mysql://localhost:3306/bigdata01?serverTimezone=UTC";
	      Connection con = null;
	      Statement st = null;
	      ResultSet rs = null;
	      
	      try {
	          
	         Class.forName(jdbc_driver);
	         con = DriverManager.getConnection(jdbc_url, "root", "bigdata");
	         st = con.createStatement();
	         
	         String sql = "SELECT * FROM bigdata01.customer";
	         rs = st.executeQuery(sql);
	 
	         while(rs.next()){       
	             String uid = rs.getString(1);
	             String uname = rs.getString(2);
	             String uphone = rs.getString(3);
	 
	             System.out.println(uid + " " + uname + " " + uphone);
	         }
	 
	      
	           
	         
	      } catch (Exception e) {
	         e.printStackTrace();
			} finally {
				 try {
					rs.close();
					st.close();
			        con.close(); 
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		         
			}
		}
	
}