
public class ArrayExam8 {

	public static void main(String[] args) {
		//공차수열 배열로 표기
		//첫째항이 5이고, 공차가 2인 공차수열.
		int [] su = new int[20];
		su[0] = 5;
		su[1] = 7;
		
		
		for(int i = 1; i<5; i++ ) {
			su[i] = (su[i] + ((i - 1)) * 2);
		}
		
		
		for(int j = 0; j < su.length; j++) {
			
//			pibo[q] = pibo[q + 1];
//			pibo[q + 1] = pibo[q + 2];
			
		System.out.println(su[j]);
		
		}
	}

}
