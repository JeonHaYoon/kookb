package service;

import model.MemberVO;

public interface LoginService {

	public MemberVO read(MemberVO vo);
}
