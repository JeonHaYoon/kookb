CREATE DATABASE  IF NOT EXISTS `bigdata` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bigdata`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_attach`
--

DROP TABLE IF EXISTS `tbl_attach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_attach` (
  `uuid` varchar(100) NOT NULL,
  `uploadpath` varchar(200) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `filetype` char(1) DEFAULT 'I',
  `bno` int DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `fk_attach_bno_idx` (`bno`),
  CONSTRAINT `fk_attach_bno` FOREIGN KEY (`bno`) REFERENCES `tbl_board` (`bno`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_attach`
--

LOCK TABLES `tbl_attach` WRITE;
/*!40000 ALTER TABLE `tbl_attach` DISABLE KEYS */;
INSERT INTO `tbl_attach` VALUES ('02547697-526b-4d1c-a90d-da03e7699c2e','2022\\11\\28','99AE6D405AFE7B1321.hwp','0',262136),('13a932b6-d467-416f-b583-cb9d9643c5ca','2022\\11\\30','99AE6D405AFE7B1321.hwp','0',262155),('384dc046-d3bf-4a51-a5f7-cb843ebfd61b','2022\\11\\24','coming.jpg','1',262135),('4527f869-7a42-4be9-a110-2014abbc16e1','2022\\11\\25','12월+프로그램지001.jpg','1',262140),('66989436-516a-4710-9482-dea610684d90','2022\\11\\30','SFC45N7UKREZXEV2ZIYXBNM6HE.jpg','1',262155),('6e049677-a14e-4ddc-8bc5-1c9f79abe65a','2022\\11\\28','coming.jpg','1',262142),('76055169-bcd2-4e96-97e6-cc5db9c1bc9f','2022\\11\\25','coming.jpg','1',262140),('8af6fe0e-1804-4ac3-ab38-044f90d23c9d','2022\\11\\25','99AE6D405AFE7B1321.hwp','0',262140),('b4fb2b17-e2aa-417f-b3ae-ec161c076946','2022\\11\\28','coming.jpg','1',262134),('b86c70f7-5a7f-4aae-8565-fb8937b2c2f2','2022\\11\\30','플로우차트.png','1',262156),('d53860be-4c30-420a-b585-15c8aa305abb','2022\\11\\24','12월+프로그램지001.jpg','1',262135),('e833ff66-9200-4f90-be0e-406521f196a0','2022\\11\\30','플로우차트.png','1',262154);
/*!40000 ALTER TABLE `tbl_attach` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-05 13:20:15
