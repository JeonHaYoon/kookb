CREATE DATABASE  IF NOT EXISTS `bigdata` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bigdata`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `big_contact`
--

DROP TABLE IF EXISTS `big_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `big_contact` (
  `co_num` int NOT NULL AUTO_INCREMENT,
  `co_fname` varchar(45) NOT NULL,
  `co_email` varchar(45) NOT NULL,
  `co_message` text,
  `co_inputdate` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`co_num`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `big_contact`
--

LOCK TABLES `big_contact` WRITE;
/*!40000 ALTER TABLE `big_contact` DISABLE KEYS */;
INSERT INTO `big_contact` VALUES (1,'안명진','rosena99@kb.co.kr','문의합니다.','2022-11-01 15:09:38'),(2,'안명진','rosena99@kb.co.kr','문의합니다.','2022-11-01 15:13:13'),(3,'안명진','d9318iron@gmail.com','문의 또 합니다.\r\n문의 또 합니다.\r\n문의 또 합니다.\r\n문의 또 합니다.','2022-11-01 15:14:42'),(4,'안명진','d9318iron@gmail.com','메세지\r\n날라가나요\r\nㅎㅎㅎ','2022-11-02 11:22:28'),(5,'안명진','d9318iron@gmail.com','내용\r\n안보내지면 앙대요','2022-11-02 11:27:58'),(6,'안명진','d9318iron@gmail.com','다음에서 받겠습니다.\r\n\r\n보내는 사람은 네이버로 해야힙니다.d9318iron@gmail.com','2022-11-02 11:30:33'),(7,'홍길동','d9318iron@gmail.com','이메일주소가 아래에 나와야하는데.. ㅠㅠ<br>d9318iron@gmail.com','2022-11-02 11:31:57'),(8,'홍길동','rosena99@kb.co.kr','html 되나요?<br>rosena99@kb.co.kr','2022-11-02 11:34:10'),(9,'안명진','d9318iron@gmail.com','html\r\n줄바뀜 ㅋㅋㅋ<br>d9318iron@gmail.com','2022-11-02 11:37:04'),(10,'안명진','d9318iron@gmail.com','한글 안깨짐 이메일 아래로 <br>d9318iron@gmail.com','2022-11-02 11:38:08');
/*!40000 ALTER TABLE `big_contact` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-05 13:20:13
