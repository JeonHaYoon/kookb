CREATE DATABASE  IF NOT EXISTS `bigdata` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bigdata`;
-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_member_auth`
--

DROP TABLE IF EXISTS `tbl_member_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_member_auth` (
  `userid` varchar(50) NOT NULL,
  `auth` varchar(50) NOT NULL,
  PRIMARY KEY (`userid`,`auth`),
  CONSTRAINT `fk_auth_userid` FOREIGN KEY (`userid`) REFERENCES `tbl_member` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_member_auth`
--

LOCK TABLES `tbl_member_auth` WRITE;
/*!40000 ALTER TABLE `tbl_member_auth` DISABLE KEYS */;
INSERT INTO `tbl_member_auth` VALUES ('admin90','ROLE_ADMIN'),('admin90','ROLE_MEMBER'),('admin91','ROLE_ADMIN'),('admin92','ROLE_ADMIN'),('admin93','ROLE_ADMIN'),('admin94','ROLE_ADMIN'),('admin95','ROLE_ADMIN'),('admin96','ROLE_ADMIN'),('admin97','ROLE_ADMIN'),('admin98','ROLE_ADMIN'),('admin99','ROLE_ADMIN'),('manager80','ROLE_MEMBER'),('manager81','ROLE_MEMBER'),('manager82','ROLE_MEMBER'),('manager83','ROLE_MEMBER'),('manager84','ROLE_MEMBER'),('manager85','ROLE_MEMBER'),('manager86','ROLE_MEMBER'),('manager87','ROLE_MEMBER'),('manager88','ROLE_MEMBER'),('manager89','ROLE_MEMBER'),('user0','ROLE_USER'),('user1','ROLE_USER'),('user10','ROLE_USER'),('user11','ROLE_USER'),('user12','ROLE_USER'),('user13','ROLE_USER'),('user14','ROLE_USER'),('user15','ROLE_USER'),('user16','ROLE_USER'),('user17','ROLE_USER'),('user18','ROLE_USER'),('user19','ROLE_USER'),('user2','ROLE_USER'),('user20','ROLE_USER'),('user21','ROLE_USER'),('user22','ROLE_USER'),('user23','ROLE_USER'),('user24','ROLE_USER'),('user25','ROLE_USER'),('user26','ROLE_USER'),('user27','ROLE_USER'),('user28','ROLE_USER'),('user29','ROLE_USER'),('user3','ROLE_USER'),('user30','ROLE_USER'),('user31','ROLE_USER'),('user32','ROLE_USER'),('user33','ROLE_USER'),('user34','ROLE_USER'),('user35','ROLE_USER'),('user36','ROLE_USER'),('user37','ROLE_USER'),('user38','ROLE_USER'),('user39','ROLE_USER'),('user4','ROLE_USER'),('user40','ROLE_USER'),('user41','ROLE_USER'),('user42','ROLE_USER'),('user43','ROLE_USER'),('user44','ROLE_USER'),('user45','ROLE_USER'),('user46','ROLE_USER'),('user47','ROLE_USER'),('user48','ROLE_USER'),('user49','ROLE_USER'),('user5','ROLE_USER'),('user50','ROLE_USER'),('user51','ROLE_USER'),('user52','ROLE_USER'),('user53','ROLE_USER'),('user54','ROLE_USER'),('user55','ROLE_USER'),('user56','ROLE_USER'),('user57','ROLE_USER'),('user58','ROLE_USER'),('user59','ROLE_USER'),('user6','ROLE_USER'),('user60','ROLE_USER'),('user61','ROLE_USER'),('user62','ROLE_USER'),('user63','ROLE_USER'),('user64','ROLE_USER'),('user65','ROLE_USER'),('user66','ROLE_USER'),('user67','ROLE_USER'),('user68','ROLE_USER'),('user69','ROLE_USER'),('user7','ROLE_USER'),('user70','ROLE_USER'),('user71','ROLE_USER'),('user72','ROLE_USER'),('user73','ROLE_USER'),('user74','ROLE_USER'),('user75','ROLE_USER'),('user76','ROLE_USER'),('user77','ROLE_USER'),('user78','ROLE_USER'),('user79','ROLE_USER'),('user8','ROLE_USER'),('user9','ROLE_USER');
/*!40000 ALTER TABLE `tbl_member_auth` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-05 13:20:13
